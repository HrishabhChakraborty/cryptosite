from django.shortcuts import render

def home(request):
    import requests
    import json
    #grab crypto price Data
    price_request = requests.get("https://min-api.cryptocompare.com/data/pricemultifull?fsyms=BTC,ETH,XRP,BHC,EOS,LTC,XLMADA,USDT,MIOTA,TRX&tsyms=USD")
    price = price_request.json()


    #grab crypto news
    api_request = requests.get("https://min-api.cryptocompare.com/data/v2/news/?lang=EN")
    api = api_request.json()
    return render(request, 'home.html', {'api' : api, 'price' : price})

# Create your views here.

def prices(request):
    if request.method == 'POST':
        import requests
        import json
        quote = request.POST['quote']
        quote = quote.upper()
        crypto_request = requests.get("https://min-api.cryptocompare.com/data/pricemultifull?fsyms=" + quote + "&tsyms=USD")
        crypto = crypto_request.json()
        return render(request, 'prices.html', {'quote':quote ,'crypto':crypto})

    else:
        notfound = "Enter a crytpo currency symbol above...."
        return render(request, 'prices.html', {'notfound' : notfound})
